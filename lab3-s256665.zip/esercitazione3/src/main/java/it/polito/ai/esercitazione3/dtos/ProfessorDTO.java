package it.polito.ai.esercitazione3.dtos;

import lombok.Data;

@Data
public class ProfessorDTO {
  String id;
  String firstName;
  String name;
}
