package it.polito.ai.esercitazione3.exceptions;

public class TeamServiceException extends RuntimeException {

  public TeamServiceException(String s) {
    super(s);
  }
}
