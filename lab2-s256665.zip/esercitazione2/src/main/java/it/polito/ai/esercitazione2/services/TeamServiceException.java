package it.polito.ai.esercitazione2.services;

public class TeamServiceException extends RuntimeException {
    public TeamServiceException(String s) {
        super(s);
    }
}
