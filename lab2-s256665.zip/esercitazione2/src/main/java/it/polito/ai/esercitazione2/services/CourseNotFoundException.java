package it.polito.ai.esercitazione2.services;

public class CourseNotFoundException extends TeamServiceException {

    public CourseNotFoundException(String s) {
        super(s);
    }
}
