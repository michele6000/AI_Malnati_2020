package it.polito.ai.esercitazione1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Esercitazione1Application {

    public static void main(String[] args) {
        SpringApplication.run(Esercitazione1Application.class, args);

    }

}
